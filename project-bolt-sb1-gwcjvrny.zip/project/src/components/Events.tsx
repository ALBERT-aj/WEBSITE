import React, { useState } from 'react';
import { Logo } from './Logo';
import { Menu, Calendar, Users, Download, ChevronRight, Flower, Handshake } from 'lucide-react';

const upcomingEvents = [
  {
    id: 'womens-day',
    title: "International Women's Day Celebration",
    date: "March 8, 2025",
    time: "6:00 PM - 9:00 PM EST",
    location: "The Grand Hall, Downtown",
    description: "Join us for an evening of inspiration, connection, and celebration as we honor the achievements and potential of women in our community. Featuring keynote speakers, panel discussions, and networking opportunities.",
    icon: Flower,
    image: "https://images.unsplash.com/photo-1564121211835-e88c852648ab?auto=format&fit=crop&q=80",
    calendarLinks: {
      google: "#",
      apple: "#",
      outlook: "#"
    }
  },
  {
    id: 'networking',
    title: "BGLU Spring Networking Mixer",
    date: "TBA",
    time: "Details Coming Soon",
    location: "Venue TBA",
    description: "Connect with fellow professionals, entrepreneurs, and industry leaders in a relaxed atmosphere. This exclusive event will feature speed networking sessions, mentorship opportunities, and refreshments.",
    icon: Handshake,
    image: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&q=80",
    status: 'upcoming'
  }
];

export function Events() {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState('March');

  return (
    <div className="min-h-screen relative bg-[#2C1810]">
      {/* Background Pattern */}
      <div className="absolute inset-0 z-0">
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1635372722656-389f87a941b7?auto=format&fit=crop&q=80")',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#2C1810] via-[#2C1810]/95 to-[#2C1810]" />
      </div>

      {/* Content */}
      <div className="relative z-10">
        {/* Navigation */}
        <nav className="flex justify-between items-center p-2 md:p-4">
          <div className="flex items-center gap-4">
            <Logo />
            <div className="relative">
              <button 
                className="flex items-center gap-1 text-white hover:text-gray-200 transition-colors duration-200"
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              >
                <Menu className="w-5 h-5" />
                <span>Menu</span>
              </button>
              {isDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 z-50">
                  <a 
                    href="/" 
                    className="block px-4 py-2 text-gray-800 hover:bg-[#B08968] hover:text-white transition-colors duration-200"
                  >
                    Home
                  </a>
                  <a 
                    href="/events" 
                    className="block px-4 py-2 text-gray-800 bg-[#B08968] text-white"
                  >
                    Events Calendar
                  </a>
                  <a 
                    href="/gallery" 
                    className="block px-4 py-2 text-gray-800 hover:bg-[#B08968] hover:text-white transition-colors duration-200"
                  >
                    Gallery
                  </a>
                </div>
              )}
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <div className="container mx-auto px-4 py-12">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-serif text-white mb-6">
              Upcoming Events
            </h1>
            <p className="text-[#B08968] text-lg md:text-xl max-w-2xl mx-auto">
              Join us for inspiring gatherings and transformative experiences
            </p>
          </div>

          {/* Month Selection */}
          <div className="flex justify-center mb-12">
            <div className="inline-flex bg-white/5 backdrop-blur-sm rounded-full p-1">
              {['March', 'April', 'May'].map((month) => (
                <button
                  key={month}
                  className={`px-6 py-2 rounded-full text-sm font-medium transition-colors duration-200 ${
                    selectedMonth === month
                      ? 'bg-[#B08968] text-white'
                      : 'text-white/70 hover:text-white'
                  }`}
                  onClick={() => setSelectedMonth(month)}
                >
                  {month}
                </button>
              ))}
            </div>
          </div>

          {/* Events Grid */}
          <div className="grid grid-cols-1 gap-8 max-w-4xl mx-auto">
            {upcomingEvents.map((event) => (
              <div
                key={event.id}
                className="bg-white/5 backdrop-blur-sm rounded-2xl overflow-hidden transform transition-all duration-300 hover:scale-[1.02]"
              >
                <div className="relative h-48 md:h-64">
                  <img
                    src={event.image}
                    alt={event.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                  <div className="absolute bottom-0 left-0 p-6">
                    <h3 className="text-2xl md:text-3xl font-serif text-white mb-2">
                      {event.title}
                    </h3>
                    <div className="flex items-center text-[#B08968]">
                      <Calendar className="w-4 h-4 mr-2" />
                      <span>{event.date}</span>
                    </div>
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="flex items-start gap-4 mb-6">
                    <div className="w-12 h-12 rounded-full bg-[#B08968]/10 flex items-center justify-center flex-shrink-0">
                      {event.icon && <event.icon className="w-6 h-6 text-[#B08968]" />}
                    </div>
                    <p className="text-white/80">
                      {event.description}
                    </p>
                  </div>

                  <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
                    <div className="flex items-center text-white/60">
                      <Users className="w-4 h-4 mr-2" />
                      <span>{event.location}</span>
                    </div>
                    
                    {event.calendarLinks ? (
                      <div className="flex gap-3">
                        <button className="px-4 py-2 bg-[#B08968] text-white rounded-full hover:bg-[#96735A] transition-colors duration-300">
                          RSVP Now
                        </button>
                        <div className="relative group">
                          <button className="px-4 py-2 bg-white/10 text-white rounded-full hover:bg-white/20 transition-colors duration-300 flex items-center gap-2">
                            <Download className="w-4 h-4" />
                            Add to Calendar
                          </button>
                          <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 hidden group-hover:block">
                            <a 
                              href={event.calendarLinks.google}
                              className="block px-4 py-2 text-gray-800 hover:bg-[#B08968] hover:text-white transition-colors duration-200"
                            >
                              Google Calendar
                            </a>
                            <a 
                              href={event.calendarLinks.apple}
                              className="block px-4 py-2 text-gray-800 hover:bg-[#B08968] hover:text-white transition-colors duration-200"
                            >
                              Apple Calendar
                            </a>
                            <a 
                              href={event.calendarLinks.outlook}
                              className="block px-4 py-2 text-gray-800 hover:bg-[#B08968] hover:text-white transition-colors duration-200"
                            >
                              Outlook
                            </a>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <button className="px-4 py-2 bg-white/10 text-white rounded-full hover:bg-white/20 transition-colors duration-300 flex items-center gap-2">
                        Notify Me
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}