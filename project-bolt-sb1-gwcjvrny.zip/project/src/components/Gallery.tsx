import React, { useState } from 'react';
import { Logo } from './Logo';
import { Menu, X } from 'lucide-react';
import Lightbox from "yet-another-react-lightbox";
import "yet-another-react-lightbox/styles.css";

const galleryThemes = [
  {
    id: 'summer-bbq',
    title: 'Summer Barbeque',
    description: 'A delightful summer gathering of our BGLU community',
    coverImage: "https://images.unsplash.com/photo-1594156596782-656c93e4d504?auto=format&fit=crop&q=80",
    images: [
      {
        src: "https://images.unsplash.com/photo-1594156596782-656c93e4d504?auto=format&fit=crop&q=80",
        title: "Summer Sky"
      },
      {
        src: "https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?auto=format&fit=crop&q=80",
        title: "Community Gathering"
      },
      {
        src: "https://images.unsplash.com/photo-1531545514256-b1400bc00f31?auto=format&fit=crop&q=80",
        title: "Annual Celebration"
      }
    ]
  },
  {
    id: 'networking',
    title: "2025's Networking Event",
    description: 'Building connections and fostering professional relationships',
    coverImage: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&q=80",
    images: [
      {
        src: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&q=80",
        title: "Networking Session"
      },
      {
        src: "https://images.unsplash.com/photo-1475721027785-f74eccf877e2?auto=format&fit=crop&q=80",
        title: "Professional Connections"
      },
      {
        src: "https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&q=80",
        title: "Business Networking"
      }
    ]
  },
  {
    id: 'guest-speaker',
    title: 'BGLU Guest Speaker Night',
    description: 'Inspiring talks from industry leaders and changemakers',
    coverImage: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&q=80",
    images: [
      {
        src: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&q=80",
        title: "Guest Speaker"
      },
      {
        src: "https://images.unsplash.com/photo-1523450001312-680111fb0b2a?auto=format&fit=crop&q=80",
        title: "Keynote Session"
      },
      {
        src: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&q=80",
        title: "Speaker Panel"
      }
    ]
  },
  {
    id: 'agm',
    title: 'BGLU AGM 2025',
    description: 'Annual General Meeting celebrating our achievements and future vision',
    coverImage: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&q=80",
    images: [
      {
        src: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&q=80",
        title: "AGM Opening"
      },
      {
        src: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&q=80",
        title: "Annual Review"
      },
      {
        src: "https://images.unsplash.com/photo-1528605248644-14dd04022da1?auto=format&fit=crop&q=80",
        title: "Team Recognition"
      }
    ]
  }
];

const backgroundImages = [
  "https://images.unsplash.com/photo-1594156596782-656c93e4d504?auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1607748862156-7c548e7e98f4?auto=format&fit=crop&q=80"
];

export function Gallery() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [selectedTheme, setSelectedTheme] = useState<string | null>(null);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  const handleThemeClick = (themeId: string) => {
    setSelectedTheme(themeId);
    const theme = galleryThemes.find(t => t.id === themeId);
    if (theme) {
      setLightboxIndex(0);
      setLightboxOpen(true);
    }
  };

  const currentTheme = selectedTheme ? galleryThemes.find(t => t.id === selectedTheme) : null;

  return (
    <div className="min-h-screen relative">
      {/* Background Collage */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 grid grid-cols-3 gap-1 opacity-20">
          {backgroundImages.map((img, index) => (
            <div key={index} className="relative">
              <img
                src={img}
                alt=""
                className="w-full h-full object-cover"
              />
            </div>
          ))}
        </div>
        <div className="absolute inset-0 bg-[#2C1810]/90 backdrop-blur-sm" />
      </div>

      {/* Content */}
      <div className="relative z-10">
        {/* Navigation */}
        <nav className="flex justify-between items-center p-2 md:p-4">
          <div className="flex items-center gap-4">
            <Logo />
            <div className="relative">
              <button 
                className="flex items-center gap-1 text-white hover:text-gray-200 transition-colors duration-200"
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              >
                <Menu className="w-5 h-5" />
                <span>Menu</span>
              </button>
              {isDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 z-50">
                  <a 
                    href="/" 
                    className="block px-4 py-2 text-gray-800 hover:bg-[#B08968] hover:text-white transition-colors duration-200"
                  >
                    Home
                  </a>
                  <a 
                    href="#" 
                    className="block px-4 py-2 text-gray-800 hover:bg-[#B08968] hover:text-white transition-colors duration-200"
                  >
                    Events Calendar
                  </a>
                  <a 
                    href="/gallery" 
                    className="block px-4 py-2 text-gray-800 bg-[#B08968] text-white transition-colors duration-200"
                  >
                    Gallery
                  </a>
                </div>
              )}
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <div className="container mx-auto px-4 py-12">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-serif text-white mb-6 drop-shadow-lg">
              Moments That Define Us
            </h1>
            <p className="text-[#B08968] text-lg md:text-xl max-w-2xl mx-auto">
              Explore our visual journey through leadership, community, and growth
            </p>
          </div>

          {/* Theme Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {galleryThemes.map((theme) => (
              <div
                key={theme.id}
                onClick={() => handleThemeClick(theme.id)}
                className="group relative overflow-hidden rounded-2xl cursor-pointer transform transition-all duration-500 hover:scale-[1.02] bg-black/40 backdrop-blur-sm"
              >
                <div className="aspect-w-16 aspect-h-9">
                  <img
                    src={theme.coverImage}
                    alt={theme.title}
                    className="w-full h-[300px] object-cover opacity-90 group-hover:opacity-100 transition-opacity duration-300"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent opacity-90 group-hover:opacity-75 transition-opacity duration-300" />
                <div className="absolute inset-0 p-8 flex flex-col justify-end">
                  <h3 className="text-white text-2xl md:text-3xl font-serif mb-2 transform transition-transform duration-300 group-hover:translate-y-[-8px]">
                    {theme.title}
                  </h3>
                  <p className="text-[#B08968] transform transition-transform duration-300 group-hover:translate-y-[-8px]">
                    {theme.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Lightbox */}
      {currentTheme && (
        <Lightbox
          open={lightboxOpen}
          close={() => setLightboxOpen(false)}
          index={lightboxIndex}
          slides={currentTheme.images.map(img => ({ src: img.src }))}
          render={{
            buttonPrev: currentTheme.images.length <= 1 ? () => null : undefined,
            buttonNext: currentTheme.images.length <= 1 ? () => null : undefined,
          }}
        />
      )}
    </div>
  );
}