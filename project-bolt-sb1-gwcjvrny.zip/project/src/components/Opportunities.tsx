import React, { useState } from 'react';
import { Logo } from './Logo';
import { 
  Menu, 
  Briefcase, 
  GraduationCap, 
  Heart, 
  Search,
  Filter,
  Plus,
  Calendar,
  Building,
  DollarSign,
  Clock,
  ChevronRight
} from 'lucide-react';

// Sample data - In a real app, this would come from an API
const opportunities = {
  jobs: [
    {
      id: 'job1',
      title: 'Senior Product Manager',
      company: 'Tech Innovation Corp',
      location: 'Remote / New York',
      salary: '$120k - $160k',
      type: 'Full-time',
      posted: '2 days ago',
      deadline: 'March 30, 2025',
      description: 'Leading product strategy for an AI-driven platform focused on financial inclusion.',
      tags: ['Product Management', 'AI/ML', 'FinTech']
    },
    {
      id: 'job2',
      title: 'Director of Operations',
      company: 'Health Solutions Inc',
      location: 'Chicago / Hybrid',
      salary: '$140k - $180k',
      type: 'Full-time',
      posted: '1 week ago',
      deadline: 'April 15, 2025',
      description: 'Overseeing operational excellence in a rapidly growing healthcare technology company.',
      tags: ['Operations', 'Healthcare', 'Leadership']
    }
  ],
  education: [
    {
      id: 'edu1',
      title: 'Women in Tech Scholarship',
      provider: 'Digital Future Foundation',
      amount: '$25,000',
      deadline: 'April 1, 2025',
      description: 'Full scholarship for women pursuing advanced degrees in technology fields.',
      type: 'Scholarship'
    },
    {
      id: 'edu2',
      title: 'Executive Leadership Program',
      provider: 'Business Excellence Institute',
      duration: '12 weeks',
      startDate: 'May 1, 2025',
      description: 'Intensive leadership development program for rising executives.',
      type: 'Program'
    }
  ],
  advocacy: [
    {
      id: 'adv1',
      title: 'Tech Mentorship Initiative',
      organization: 'Women in STEM Alliance',
      commitment: '5 hours/month',
      impact: '500+ mentees supported',
      description: 'Connect with aspiring tech professionals as a mentor and guide.',
      type: 'Mentorship'
    },
    {
      id: 'adv2',
      title: 'Digital Literacy Campaign',
      organization: 'Community Tech Network',
      commitment: 'Flexible',
      impact: 'Reaching 1000+ students',
      description: 'Volunteer to teach basic digital skills in underserved communities.',
      type: 'Volunteer'
    }
  ]
};

export function Opportunities() {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('jobs');
  const [showSubmitForm, setShowSubmitForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    setShowSubmitForm(false);
  };

  return (
    <div className="min-h-screen bg-[#2C1810]">
      {/* Background Pattern */}
      <div className="absolute inset-0 z-0">
        <div 
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&q=80")',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#2C1810] via-[#2C1810]/95 to-[#2C1810]" />
      </div>

      {/* Content */}
      <div className="relative z-10">
        {/* Navigation */}
        <nav className="flex justify-between items-center p-4">
          <div className="flex items-center gap-4">
            <Logo />
            <div className="relative">
              <button 
                className="flex items-center gap-1 text-white hover:text-gray-200 transition-colors duration-200"
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              >
                <Menu className="w-5 h-5" />
                <span>Menu</span>
              </button>
              {isDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 z-50">
                  <a 
                    href="/" 
                    className="block px-4 py-2 text-gray-800 hover:bg-[#B08968] hover:text-white transition-colors duration-200"
                  >
                    Home
                  </a>
                  <a 
                    href="/events" 
                    className="block px-4 py-2 text-gray-800 hover:bg-[#B08968] hover:text-white transition-colors duration-200"
                  >
                    Events Calendar
                  </a>
                  <a 
                    href="/gallery" 
                    className="block px-4 py-2 text-gray-800 hover:bg-[#B08968] hover:text-white transition-colors duration-200"
                  >
                    Gallery
                  </a>
                  <a 
                    href="/opportunities" 
                    className="block px-4 py-2 text-gray-800 bg-[#B08968] text-white"
                  >
                    Opportunities
                  </a>
                </div>
              )}
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <div className="container mx-auto px-4 py-12">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-serif text-white mb-6">
              Opportunities Hub
            </h1>
            <p className="text-[#B08968] text-lg md:text-xl max-w-2xl mx-auto">
              Discover and share opportunities that empower our community
            </p>
          </div>

          {/* Search and Filter Bar */}
          <div className="max-w-4xl mx-auto mb-12">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/50 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search opportunities..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-white/10 border border-white/10 rounded-lg py-3 pl-12 pr-4 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#B08968]"
                />
              </div>
              <button
                onClick={() => setShowSubmitForm(true)}
                className="px-6 py-3 bg-[#B08968] text-white rounded-lg hover:bg-[#96735A] transition-colors duration-300 flex items-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Submit Opportunity
              </button>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex justify-center mb-12">
            <div className="inline-flex bg-white/5 backdrop-blur-sm rounded-full p-1">
              <button
                onClick={() => setActiveTab('jobs')}
                className={`px-6 py-2 rounded-full text-sm font-medium transition-colors duration-200 flex items-center gap-2 ${
                  activeTab === 'jobs'
                    ? 'bg-[#B08968] text-white'
                    : 'text-white/70 hover:text-white'
                }`}
              >
                <Briefcase className="w-4 h-4" />
                Jobs
              </button>
              <button
                onClick={() => setActiveTab('education')}
                className={`px-6 py-2 rounded-full text-sm font-medium transition-colors duration-200 flex items-center gap-2 ${
                  activeTab === 'education'
                    ? 'bg-[#B08968] text-white'
                    : 'text-white/70 hover:text-white'
                }`}
              >
                <GraduationCap className="w-4 h-4" />
                Education
              </button>
              <button
                onClick={() => setActiveTab('advocacy')}
                className={`px-6 py-2 rounded-full text-sm font-medium transition-colors duration-200 flex items-center gap-2 ${
                  activeTab === 'advocacy'
                    ? 'bg-[#B08968] text-white'
                    : 'text-white/70 hover:text-white'
                }`}
              >
                <Heart className="w-4 h-4" />
                Advocacy
              </button>
            </div>
          </div>

          {/* Opportunities Grid */}
          <div className="grid grid-cols-1 gap-6 max-w-4xl mx-auto">
            {activeTab === 'jobs' && opportunities.jobs.map((job) => (
              <div
                key={job.id}
                className="bg-white/5 backdrop-blur-sm rounded-lg p-6 hover:bg-white/10 transition-colors duration-300"
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-serif text-white mb-2">{job.title}</h3>
                    <div className="flex items-center gap-2 text-[#B08968]">
                      <Building className="w-4 h-4" />
                      <span>{job.company}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-white/60">
                    <DollarSign className="w-4 h-4" />
                    <span>{job.salary}</span>
                  </div>
                </div>
                <p className="text-white/80 mb-4">{job.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {job.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-3 py-1 bg-[#B08968]/20 text-[#B08968] rounded-full text-sm"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                <div className="flex justify-between items-center text-sm text-white/60">
                  <div className="flex items-center gap-4">
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {job.posted}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      Due {job.deadline}
                    </span>
                  </div>
                  <button className="text-[#B08968] hover:text-white transition-colors duration-200 flex items-center gap-1">
                    Learn More
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}

            {activeTab === 'education' && opportunities.education.map((edu) => (
              <div
                key={edu.id}
                className="bg-white/5 backdrop-blur-sm rounded-lg p-6 hover:bg-white/10 transition-colors duration-300"
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-serif text-white mb-2">{edu.title}</h3>
                    <div className="flex items-center gap-2 text-[#B08968]">
                      <Building className="w-4 h-4" />
                      <span>{edu.provider}</span>
                    </div>
                  </div>
                  <span className="px-3 py-1 bg-[#B08968]/20 text-[#B08968] rounded-full text-sm">
                    {edu.type}
                  </span>
                </div>
                <p className="text-white/80 mb-4">{edu.description}</p>
                <div className="flex justify-between items-center text-sm text-white/60">
                  <div className="flex items-center gap-4">
                    {edu.amount && (
                      <span className="flex items-center gap-1">
                        <DollarSign className="w-4 h-4" />
                        {edu.amount}
                      </span>
                    )}
                    {edu.deadline && (
                      <span className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        Due {edu.deadline}
                      </span>
                    )}
                  </div>
                  <button className="text-[#B08968] hover:text-white transition-colors duration-200 flex items-center gap-1">
                    Learn More
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}

            {activeTab === 'advocacy' && opportunities.advocacy.map((adv) => (
              <div
                key={adv.id}
                className="bg-white/5 backdrop-blur-sm rounded-lg p-6 hover:bg-white/10 transition-colors duration-300"
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-serif text-white mb-2">{adv.title}</h3>
                    <div className="flex items-center gap-2 text-[#B08968]">
                      <Building className="w-4 h-4" />
                      <span>{adv.organization}</span>
                    </div>
                  </div>
                  <span className="px-3 py-1 bg-[#B08968]/20 text-[#B08968] rounded-full text-sm">
                    {adv.type}
                  </span>
                </div>
                <p className="text-white/80 mb-4">{adv.description}</p>
                <div className="flex justify-between items-center text-sm text-white/60">
                  <div className="flex items-center gap-4">
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {adv.commitment}
                    </span>
                    <span>{adv.impact}</span>
                  </div>
                  <button className="text-[#B08968] hover:text-white transition-colors duration-200 flex items-center gap-1">
                    Get Involved
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Submit Opportunity Form Modal */}
      {showSubmitForm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="bg-[#2C1810] border border-white/10 rounded-lg p-8 max-w-2xl w-full mx-4">
            <h2 className="text-2xl font-serif text-white mb-6">Submit an Opportunity</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-[#B08968] mb-2">
                  Opportunity Type
                </label>
                <select className="w-full bg-white/5 border border-white/10 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-[#B08968]">
                  <option value="job">Job Opening</option>
                  <option value="education">Educational Program</option>
                  <option value="advocacy">Advocacy Initiative</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#B08968] mb-2">
                  Title
                </label>
                <input
                  type="text"
                  className="w-full bg-white/5 border border-white/10 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-[#B08968]"
                  placeholder="Enter opportunity title"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#B08968] mb-2">
                  Description
                </label>
                <textarea
                  rows={4}
                  className="w-full bg-white/5 border border-white/10 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-[#B08968]"
                  placeholder="Describe the opportunity..."
                />
              </div>
              <div className="flex justify-end gap-4">
                <button
                  type="button"
                  onClick={() => setShowSubmitForm(false)}
                  className="px-6 py-2 text-white hover:text-[#B08968] transition-colors duration-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-[#B08968] text-white rounded-lg hover:bg-[#96735A] transition-colors duration-300"
                >
                  Submit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}