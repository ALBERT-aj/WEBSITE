import React, { useState } from 'react';
import { Logo } from './Logo';
import { User, Mail, Briefcase, Globe, Phone, Camera, ArrowLeft } from 'lucide-react';

export function Signup() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    profession: '',
    company: '',
    yearsOfExperience: '',
    linkedIn: '',
    website: '',
    phone: '',
    goals: [],
    interests: [],
    photo: null,
    bio: '',
    referralSource: '',
    membershipTier: ''
  });

  const goals = [
    'Career Advancement',
    'Business Growth',
    'Networking',
    'Skill Development',
    'Mentorship',
    'Leadership Development',
    'Work-Life Balance',
    'Personal Branding'
  ];

  const interests = [
    'Technology',
    'Entrepreneurship',
    'Finance',
    'Marketing',
    'Healthcare',
    'Education',
    'Creative Arts',
    'Social Impact'
  ];

  const membershipTiers = [
    {
      name: 'Rising Star',
      price: '97/month',
      features: [
        'Access to Community Platform',
        'Monthly Virtual Networking',
        'Resource Library',
        'Member Directory Access'
      ]
    },
    {
      name: 'Accelerator',
      price: '197/month',
      features: [
        'All Rising Star Benefits',
        'Quarterly 1:1 Mentoring',
        'Priority Event Access',
        'Exclusive Workshops',
        'Industry Connections'
      ]
    },
    {
      name: 'Elite Circle',
      price: '397/month',
      features: [
        'All Accelerator Benefits',
        'Monthly 1:1 Coaching',
        'Mastermind Group',
        'Speaking Opportunities',
        'Featured Member Profile',
        'VIP Event Access'
      ]
    }
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (type: 'goals' | 'interests', value: string) => {
    setFormData(prev => ({
      ...prev,
      [type]: prev[type].includes(value)
        ? prev[type].filter(item => item !== value)
        : [...prev[type], value]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step < 3) {
      setStep(step + 1);
    } else {
      // Handle form submission
      console.log('Form submitted:', formData);
    }
  };

  return (
    <div className="min-h-screen bg-[#2C1810]">
      <div className="absolute inset-0 z-0">
        <div 
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1511497584788-876760111969?auto=format&fit=crop&q=80")',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#2C1810] via-[#2C1810]/95 to-[#2C1810]" />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <a href="/" className="flex items-center text-white hover:text-[#B08968] transition-colors duration-200">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Home
            </a>
            <Logo />
          </div>

          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-8">
            <h1 className="text-3xl font-serif text-white text-center mb-2">Join Our Community</h1>
            <p className="text-[#B08968] text-center mb-8">Step {step} of 3</p>

            <form onSubmit={handleSubmit} className="space-y-6">
              {step === 1 && (
                <div className="space-y-6">
                  <h2 className="text-xl font-serif text-white mb-4">Personal Information</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-[#B08968] mb-2">
                        First Name
                      </label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/50 w-5 h-5" />
                        <input
                          type="text"
                          name="firstName"
                          value={formData.firstName}
                          onChange={handleInputChange}
                          className="w-full bg-white/5 border border-white/10 rounded-lg py-3 pl-12 pr-4 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#B08968] focus:border-transparent"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-[#B08968] mb-2">
                        Last Name
                      </label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/50 w-5 h-5" />
                        <input
                          type="text"
                          name="lastName"
                          value={formData.lastName}
                          onChange={handleInputChange}
                          className="w-full bg-white/5 border border-white/10 rounded-lg py-3 pl-12 pr-4 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#B08968] focus:border-transparent"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-[#B08968] mb-2">
                        Email Address
                      </label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/50 w-5 h-5" />
                        <input
                          type="email"
                          name="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          className="w-full bg-white/5 border border-white/10 rounded-lg py-3 pl-12 pr-4 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#B08968] focus:border-transparent"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-[#B08968] mb-2">
                        Phone Number
                      </label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/50 w-5 h-5" />
                        <input
                          type="tel"
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          className="w-full bg-white/5 border border-white/10 rounded-lg py-3 pl-12 pr-4 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#B08968] focus:border-transparent"
                          required
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-[#B08968] mb-2">
                      Professional Bio
                    </label>
                    <textarea
                      name="bio"
                      value={formData.bio}
                      onChange={handleInputChange}
                      rows={4}
                      className="w-full bg-white/5 border border-white/10 rounded-lg py-3 px-4 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#B08968] focus:border-transparent"
                      placeholder="Tell us about yourself..."
                      required
                    />
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-6">
                  <h2 className="text-xl font-serif text-white mb-4">Professional Information</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-[#B08968] mb-2">
                        Profession
                      </label>
                      <div className="relative">
                        <Briefcase className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/50 w-5 h-5" />
                        <input
                          type="text"
                          name="profession"
                          value={formData.profession}
                          onChange={handleInputChange}
                          className="w-full bg-white/5 border border-white/10 rounded-lg py-3 pl-12 pr-4 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#B08968] focus:border-transparent"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-[#B08968] mb-2">
                        Company
                      </label>
                      <div className="relative">
                        <Briefcase className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/50 w-5 h-5" />
                        <input
                          type="text"
                          name="company"
                          value={formData.company}
                          onChange={handleInputChange}
                          className="w-full bg-white/5 border border-white/10 rounded-lg py-3 pl-12 pr-4 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#B08968] focus:border-transparent"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-[#B08968] mb-2">
                        LinkedIn Profile
                      </label>
                      <div className="relative">
                        <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/50 w-5 h-5" />
                        <input
                          type="url"
                          name="linkedIn"
                          value={formData.linkedIn}
                          onChange={handleInputChange}
                          className="w-full bg-white/5 border border-white/10 rounded-lg py-3 pl-12 pr-4 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#B08968] focus:border-transparent"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-[#B08968] mb-2">
                        Website
                      </label>
                      <div className="relative">
                        <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/50 w-5 h-5" />
                        <input
                          type="url"
                          name="website"
                          value={formData.website}
                          onChange={handleInputChange}
                          className="w-full bg-white/5 border border-white/10 rounded-lg py-3 pl-12 pr-4 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#B08968] focus:border-transparent"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-[#B08968] mb-4">
                      Areas of Interest
                    </label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {interests.map(interest => (
                        <label
                          key={interest}
                          className="flex items-center space-x-2 cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            checked={formData.interests.includes(interest)}
                            onChange={() => handleCheckboxChange('interests', interest)}
                            className="form-checkbox text-[#B08968] rounded border-white/30 bg-white/5"
                          />
                          <span className="text-white text-sm">{interest}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-[#B08968] mb-4">
                      Professional Goals
                    </label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {goals.map(goal => (
                        <label
                          key={goal}
                          className="flex items-center space-x-2 cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            checked={formData.goals.includes(goal)}
                            onChange={() => handleCheckboxChange('goals', goal)}
                            className="form-checkbox text-[#B08968] rounded border-white/30 bg-white/5"
                          />
                          <span className="text-white text-sm">{goal}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-8">
                  <h2 className="text-xl font-serif text-white mb-4">Choose Your Membership</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {membershipTiers.map((tier) => (
                      <div
                        key={tier.name}
                        className={`relative rounded-lg p-6 ${
                          formData.membershipTier === tier.name
                            ? 'bg-[#B08968] text-white'
                            : 'bg-white/5 text-white'
                        }`}
                      >
                        <input
                          type="radio"
                          name="membershipTier"
                          value={tier.name}
                          checked={formData.membershipTier === tier.name}
                          onChange={handleInputChange}
                          className="sr-only"
                          id={tier.name}
                        />
                        <label
                          htmlFor={tier.name}
                          className="cursor-pointer block"
                        >
                          <div className="text-lg font-serif mb-2">{tier.name}</div>
                          <div className="text-2xl font-bold mb-4">${tier.price}</div>
                          <ul className="space-y-2">
                            {tier.features.map((feature) => (
                              <li key={feature} className="flex items-center text-sm">
                                <span className="mr-2">•</span>
                                {feature}
                              </li>
                            ))}
                          </ul>
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-between pt-6">
                {step > 1 && (
                  <button
                    type="button"
                    onClick={() => setStep(step - 1)}
                    className="px-6 py-2 text-white hover:text-[#B08968] transition-colors duration-200"
                  >
                    Back
                  </button>
                )}
                <button
                  type="submit"
                  className="px-8 py-3 bg-[#B08968] text-white rounded-lg hover:bg-[#96735A] transition-colors duration-300 ml-auto"
                >
                  {step === 3 ? 'Complete Registration' : 'Continue'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}