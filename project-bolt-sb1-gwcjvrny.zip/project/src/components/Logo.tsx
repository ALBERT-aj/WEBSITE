import React from 'react';

export function Logo() {
  return (
    <a href="/" className="flex flex-col items-start hover:opacity-80 transition-opacity duration-200">
      {/* BGLU Logo */}
      <div className="flex items-center">
        {/* BG */}
        <span className="text-white text-3xl font-bold tracking-tighter">BG</span>
        {/* LU */}
        <span className="text-[#B08968] text-3xl font-bold tracking-tighter">LU</span>
      </div>
      
      {/* BLACK GIRLS LEVEL UP Text */}
      <div className="flex flex-col -mt-1">
        <div className="flex">
          <span className="text-white text-xs tracking-widest font-bold">BLACK</span>
          <span className="text-white text-xs tracking-widest font-bold ml-1">GIRLS</span>
        </div>
        <div className="flex items-center">
          <span className="text-[#B08968] text-xs tracking-widest font-bold">LEVEL</span>
          <span className="text-[#B08968] text-xs tracking-widest font-bold ml-1">UP</span>
        </div>
      </div>
    </a>
  );
}