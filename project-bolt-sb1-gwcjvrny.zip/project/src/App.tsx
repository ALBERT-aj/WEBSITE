import React, { useState } from 'react';
import { Star, Network, Users, Menu } from 'lucide-react';
import { Logo } from './components/Logo';
import { ArticleCard } from './components/ArticleCard';
import { FaqItem } from './components/FaqItem';
import { TypewriterText } from './components/TypewriterText';
import { Gallery } from './components/Gallery';
import { Events } from './components/Events';
import { Login } from './components/Login';
import { Signup } from './components/Signup';
import { Opportunities } from './components/Opportunities';

function App() {
  // Check if we're on a specific page
  const path = window.location.pathname;
  
  if (path === '/gallery') {
    return <Gallery />;
  }
  
  if (path === '/events') {
    return <Events />;
  }

  if (path === '/login') {
    return <Login />;
  }

  if (path === '/signup') {
    return <Signup />;
  }

  if (path === '/opportunities') {
    return <Opportunities />;
  }

  const [email, setEmail] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('articles');

  const articles = [
    {
      title: "Building Wealth Through Real Estate Investment",
      excerpt: "Discover how successful Black women entrepreneurs are creating generational wealth through strategic real estate investments.",
      category: "Wealth Building",
      date: "Mar 15, 2024",
      readTime: "8 min read",
      imageUrl: "https://images.unsplash.com/photo-1560520653-9e0e4c89eb11?auto=format&fit=crop&q=80"
    },
    {
      title: "Navigating Corporate Leadership as a Black Woman",
      excerpt: "Strategies and insights for breaking through the glass ceiling while maintaining authenticity and influence.",
      category: "Leadership",
      date: "Mar 12, 2024",
      readTime: "6 min read",
      imageUrl: "https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?auto=format&fit=crop&q=80"
    },
    {
      title: "Tech Startups: From Idea to Series A",
      excerpt: "A comprehensive guide to launching and scaling your tech startup, with insights from successful Black women founders.",
      category: "Entrepreneurship",
      date: "Mar 10, 2024",
      readTime: "10 min read",
      imageUrl: "https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&q=80"
    }
  ];

  const faqs = [
    {
      question: "How can I join the Black Girls Level Up community?",
      answer: "Joining our community is simple! Click the 'Join Us Today' button at the top of the page to begin your application. We review applications weekly and will reach out within 3-5 business days."
    },
    {
      question: "What resources are available to members?",
      answer: "Members get access to our exclusive mentorship program, monthly masterclasses, networking events, resource library, and private community platform. You'll also receive invitations to our quarterly in-person events and annual retreat."
    },
    {
      question: "Is there a membership fee?",
      answer: "Yes, we offer different membership tiers to suit your needs and goals. Our basic membership starts at $97/month, with premium tiers available for additional benefits and resources."
    }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Email submitted:', email);
    setEmail('');
  };

  return (
    <div className="relative">
      {/* Hero Section */}
      <section className="relative h-screen">
        <div 
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1511497584788-876760111969?auto=format&fit=crop&q=80")',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            height: 'calc(100% + 4rem)',
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/80" />
        </div>

        <div className="relative z-10 h-full flex flex-col">
          <nav className="flex justify-between items-center p-4 md:p-6">
            <div className="flex items-center gap-6">
              <Logo />
              <div className="relative">
                <button 
                  className="flex items-center gap-2 text-white hover:text-gray-200 transition-colors duration-200"
                  onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                >
                  <Menu className="w-5 h-5" />
                  <span>Menu</span>
                </button>
                {isDropdownOpen && (
                  <div className="absolute top-full left-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 z-50">
                    <a 
                      href="/events" 
                      className="block px-4 py-2 text-gray-800 hover:bg-[#B08968] hover:text-white transition-colors duration-200"
                    >
                      Events Calendar
                    </a>
                    <a 
                      href="/gallery" 
                      className="block px-4 py-2 text-gray-800 hover:bg-[#B08968] hover:text-white transition-colors duration-200"
                    >
                      Gallery
                    </a>
                    <a 
                      href="/opportunities" 
                      className="block px-4 py-2 text-gray-800 hover:bg-[#B08968] hover:text-white transition-colors duration-200"
                    >
                      Opportunities
                    </a>
                  </div>
                )}
              </div>
            </div>
            <a 
              href="/login"
              className="px-6 py-2 bg-white/10 backdrop-blur-sm text-white rounded-lg hover:bg-white/20 transition-all duration-300"
            >
              Sign In
            </a>
          </nav>

          <div className="flex-1 flex flex-col justify-center items-center text-center px-4 md:px-8 lg:px-16">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-3xl md:text-5xl lg:text-6xl font-serif text-white mb-6 leading-tight">
                Black Girls Level Up is more than a community—
                <span className="text-[#B08968] glow-text">It's your UNFAIR ADVANTAGE</span>
              </h1>

              <div className="grid grid-cols-3 gap-4 mb-8">
                <div className="flex flex-col items-center text-white/90">
                  <Network className="w-8 h-8 mb-2 text-[#B08968]" />
                  <span className="text-sm md:text-base">Expand Your Network</span>
                </div>
                <div className="flex flex-col items-center text-white/90">
                  <Star className="w-8 h-8 mb-2 text-[#B08968]" />
                  <span className="text-sm md:text-base">Unlock Your Potential</span>
                </div>
                <div className="flex flex-col items-center text-white/90">
                  <Users className="w-8 h-8 mb-2 text-[#B08968]" />
                  <span className="text-sm md:text-base">Thrive in Community</span>
                </div>
              </div>

              <p className="text-white text-xl md:text-2xl mb-6">Are you ready to level up?</p>

              <a 
                href="https://forms.gle/j8486WuCsDn4iJHVA"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block z-20 px-8 py-4 bg-[#B08968] text-white rounded-full hover:bg-[#96735A] transition-colors duration-300 text-lg shadow-lg transform hover:scale-105 transition-transform mb-16"
              >
                Join BGLU Today
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Articles & FAQs Section */}
      <section className="bg-[#F5F2EF] py-16 md:py-24">
        <div className="container mx-auto px-4 md:px-8">
          <div className="max-w-4xl mx-auto mb-12 text-center">
            {/* Decorative spacer */}
            <div className="w-24 h-1 bg-[#B08968] mx-auto mb-12 rounded-full" />
            
            <h2 className="text-3xl md:text-4xl font-serif text-[#2C1810] mb-4">
              <TypewriterText text="Resources & Support" />
            </h2>
            <p className="text-gray-600">
              <TypewriterText text="Explore our curated content and get answers to your questions" />
            </p>
          </div>

          {/* Tabs */}
          <div className="flex justify-center mb-12">
            <div className="inline-flex bg-white rounded-full p-1 shadow-md">
              <button
                className={`px-6 py-2 rounded-full text-sm font-medium transition-colors duration-200 ${
                  activeTab === 'articles'
                    ? 'bg-[#B08968] text-white'
                    : 'text-gray-600 hover:text-[#B08968]'
                }`}
                onClick={() => setActiveTab('articles')}
              >
                Articles
              </button>
              <button
                className={`px-6 py-2 rounded-full text-sm font-medium transition-colors duration-200 ${
                  activeTab === 'faqs'
                    ? 'bg-[#B08968] text-white'
                    : 'text-gray-600 hover:text-[#B08968]'
                }`}
                onClick={() => setActiveTab('faqs')}
              >
                FAQs
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="max-w-5xl mx-auto">
            {activeTab === 'articles' ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {articles.map((article, index) => (
                  <ArticleCard key={index} {...article} />
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow-lg p-6 md:p-8">
                {faqs.map((faq, index) => (
                  <FaqItem key={index} {...faq} />
                ))}
              </div>
            )}
          </div>

          {/* View All Button */}
          <div className="text-center mt-12">
            <button className="px-8 py-3 bg-[#B08968] text-white rounded-full hover:bg-[#96735A] transition-colors duration-300 shadow-md">
              View All {activeTab === 'articles' ? 'Articles' : 'FAQs'}
            </button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-white py-12">
        <div className="container mx-auto px-4 md:px-8 flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="lg:w-1/2">
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1635372722656-389f87a941b7?auto=format&fit=crop&q=80&w=800" 
                alt="Abstract background" 
                className="w-full rounded-lg shadow-xl"
              />
              <div className="absolute inset-0 flex items-center justify-center bg-black/30 rounded-lg">
                <div className="text-center">
                  <h3 className="text-4xl md:text-5xl font-serif text-white font-bold mb-2">2025</h3>
                  <p className="text-xl md:text-2xl text-white font-serif">Year of Winners</p>
                </div>
              </div>
            </div>
          </div>
          <div className="lg:w-1/2">
            <h2 className="text-2xl md:text-4xl font-serif text-[#2C1810] mb-4 md:mb-6">
              This is your moment. Let's build something extraordinary together.
            </h2>
            <p className="text-gray-600 text-sm md:text-base mb-6 md:mb-8">
              If you're ready to amplify your success while building authentic connections with women who truly get you, BGLU is the community you've been waiting for.
            </p>
            <a 
              href="https://forms.gle/j8486WuCsDn4iJHVA"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-6 py-3 md:px-8 md:py-4 bg-[#B08968] text-white rounded-full hover:bg-[#96735A] transition-colors duration-300"
            >
              Get connected
            </a>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="bg-[#2C1810] text-white min-h-screen py-12 md:py-16">
        <div className="container mx-auto px-4 md:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <Logo />
            <h2 className="text-xl md:text-2xl font-serif mb-4 md:mb-6 mt-6 md:mt-8">Stay in the loop!</h2>
            <p className="text-sm md:text-base mb-6 md:mb-8">
              Subscribe to our newsletter for insights, updates, and exclusive opportunities designed to 
              empower and elevate Black professional women in all fields.
            </p>
            <form onSubmit={handleSubmit} className="flex flex-col gap-3 md:gap-4 max-w-2xl mx-auto">
              <input
                type="text"
                placeholder="First Name"
                className="px-4 py-2 md:px-6 md:py-3 rounded-lg bg-white/10 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-[#B08968]"
              />
              <input
                type="text"
                placeholder="Last Name"
                className="px-4 py-2 md:px-6 md:py-3 rounded-lg bg-white/10 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-[#B08968]"
              />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email Address"
                className="px-4 py-2 md:px-6 md:py-3 rounded-lg bg-white/10 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-[#B08968]"
                required
              />
              <button
                type="submit"
                className="px-6 py-3 md:px-8 md:py-4 bg-[#B08968] text-white rounded-full hover:bg-[#96735A] transition-colors duration-300"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
}

export default App;